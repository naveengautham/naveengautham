import Home from './HomePage';
import PrivateRoute from './PrivateRoute';
import Products from './ProductsPage';
import SingleProduct from './SingleProductPage';
import About from './AboutPage';
import Cart from './CartPage';
import Error from './ErrorPage';
import Checkout from './CheckoutPage';

export {
    Home, PrivateRoute, Products, SingleProduct, About, Cart, Error, Checkout
}