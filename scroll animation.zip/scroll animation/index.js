const box= document.querySelectorAll(".boxes")

window.addEventListener('scroll',checkboxes)

checkboxes()

function checkboxes() {
    
const triggerBottom= window.innerHeight / 5 * 5
console.log(triggerBottom)
box.forEach(boxes => {
    const topbox= boxes.getBoundingClientRect().top
    if(topbox < triggerBottom){
        boxes.classList.add('show')
    }else{
        boxes.classList.remove('show')
    }
});
}